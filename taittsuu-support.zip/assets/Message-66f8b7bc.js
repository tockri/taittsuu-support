const e=t=>t!==null&&typeof t=="object",o={isRecord:e},c=t=>s=>o.isRecord(s)&&s.method===t,i=c("Shift"),n=()=>({method:"Shift"}),h={isShift:i,shift:n};export{h as M};
