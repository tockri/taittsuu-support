(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/taittsuu.ts-7b8199bc.js")
    );
  })().catch(console.error);

})();
